﻿namespace Zoo
{
    public class Bear : Mammal
    {
        public Bear(string name) : base(name) { }
        public string Name { get; set; }
    }
}
