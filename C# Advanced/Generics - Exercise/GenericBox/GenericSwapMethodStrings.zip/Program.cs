﻿namespace GenericBox
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Box<string>> list = new List<Box<string>>();

            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Box<string> box = new Box<string>(Console.ReadLine());
                list.Add(box);

            }

            int[] indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int index1 = indexes[0];
            int index2 = indexes[1];

            (list[index1].Value, list[index2].Value) = (list[index2].Value, list[index1].Value);

            foreach (var box in list)
            {
                Console.WriteLine(box.ToString());
            }
        }
    }
}
