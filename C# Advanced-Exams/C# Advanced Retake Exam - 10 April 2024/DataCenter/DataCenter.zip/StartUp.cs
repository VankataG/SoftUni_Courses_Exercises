﻿using System.ComponentModel;

namespace DataCenter
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
