﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=ASUS_TUF_FX504;Database=MusicHub;Trusted_Connection=True";
    }
}
