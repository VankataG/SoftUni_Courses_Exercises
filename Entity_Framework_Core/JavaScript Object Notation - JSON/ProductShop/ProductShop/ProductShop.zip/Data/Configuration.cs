﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=ASUS_TUF_FX504;Database=ProductShop;Integrated Security=True";
    }
}
